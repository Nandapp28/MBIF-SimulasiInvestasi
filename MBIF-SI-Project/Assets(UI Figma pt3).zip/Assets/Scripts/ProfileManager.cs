using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ProfileManager : MonoBehaviour
{
    [Header("Profile Display")]
    public Image profileBorder;
    public Image profilePicture;
    public Text nicknameText;

    [Header("Popup References")]
    public GameObject popupPanel;
    public InputField inputNickname;

    private Sprite selectedAvatar;
    private Sprite selectedBorder;

    void Start()
    {
        popupPanel.SetActive(false);
    }

    public void OnProfileClicked()
    {
        popupPanel.SetActive(true);
        inputNickname.text = nicknameText.text;
    }

    public void OnCancelClicked()
    {
        popupPanel.SetActive(false);
        selectedAvatar = null;
        selectedBorder = null;
    }

    public void OnSaveClicked()
    {
        nicknameText.text = inputNickname.text;

        if (selectedAvatar != null)
            profilePicture.sprite = selectedAvatar;

        if (selectedBorder != null)
            profileBorder.sprite = selectedBorder;

        popupPanel.SetActive(false);
    }

    public void SelectProfilePicture(Sprite avatar)
    {
        selectedAvatar = avatar;
    }

    public void SelectBorder(Sprite border)
    {
        selectedBorder = border;
    }
}
