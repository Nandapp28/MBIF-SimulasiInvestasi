using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class AvatarSelector : MonoBehaviour
{
    [Header("Dependencies")]
    public ProfileManager profileManager;
    public Image avatarImage; // Ini adalah image dari tombol/avatar yang dipilih user

    public void OnClickSelectAvatar()
    {
        if (profileManager != null && avatarImage != null)
        {
            profileManager.SelectProfilePicture(avatarImage.sprite);
        }
        else
        {
            Debug.LogWarning("ProfileManager atau AvatarImage belum di-assign di inspector.");
        }
    }
}
