using UnityEngine;

public class CardUI : MonoBehaviour
{
    public bool isTaken = false;
}
